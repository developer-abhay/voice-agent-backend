export type Client = {
  clientId: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
  updatedAt: string;
};
