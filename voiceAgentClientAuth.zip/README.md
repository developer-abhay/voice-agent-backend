﻿# voice-agent-demo

## API Documentation

https://docs.google.com/document/d/1z2sblQhwE4zFkG8KDAy4boAGVJ8F9NWQV_S4RRijpTI/edit?addon_store

### Deployed URL (render) - https://voice-agent-demo-1.onrender.com/

### Base URL : /api/v1

## More things to add in Signup and SignIn

1. inputs type validation using zod
1. Password hashing
1. Efficient query using indexes instead of scan
1. Better Error handing
